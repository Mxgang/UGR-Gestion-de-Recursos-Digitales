# dai/views.py

from django.shortcuts import render, HttpResponse
from .models import Musician
from django.views.generic import TemplateView


class Home(TemplateView):
    template_name = 'account/login.html'


def index(request):
    return HttpResponse('Hello World!')


def pok(request):
	return render(request, 'index2.html')

def musicos(request):
	todos = Musician.objects.all()
	m ={ 'musicos': todos }
	return render(request, 'musicos.html', m)


def creamusico(request):
	b = Musician(first_name='John', last_name='Lenon')
	b.save()
	return render(request, 'index2.html')	
