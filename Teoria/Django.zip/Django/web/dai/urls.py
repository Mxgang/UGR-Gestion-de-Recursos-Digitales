# dai/urls.py
from django.urls import path
from django.conf.urls import url

from . import views

urlpatterns = [

  #path('', views.Home.as_view(), name='home'),
  #url('pok', views.pok, name='index2.html'),
  #url('musicos', views.musicos, name='musicos.html'),
  #url('creaJhon', views.creamusico, name='Jhon'),
  
]
