from django.db import models

# Create your models here.

class Musician(models.Model):
	first_name   = models.CharField(max_length=50, primary_key=True)
	last_name    = models.CharField(max_length=50, blank=True)
	instrument   = models.CharField(
		max_length=50,
		default   = 'piano',
		choices   = {('piano', "Piano"), ('guitar', 'Guitar'), ('flute', 'Flute')},
		help_text = "Seleccione el instrumento")
	class Meta:
		ordering = ['first_name']
		verbose_name = 'Músicos'
		indexes = [
			models.Index(fields=['last_name', 'first_name']),
			]
		

class Album(models.Model):
	artist       = models.ForeignKey(Musician, on_delete=models.CASCADE)
	name         = models.CharField(max_length=100)
	release_date = models.DateField()
	num_stars    = models.IntegerField()
