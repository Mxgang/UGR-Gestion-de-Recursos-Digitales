from django.apps import AppConfig


class DaiConfig(AppConfig):
    name = 'dai'
