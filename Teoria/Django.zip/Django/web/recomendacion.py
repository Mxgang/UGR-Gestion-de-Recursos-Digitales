import csv
import requests

# Meter las películas en un diccionario

def moviesDict():
	moviesDict = []
	with open('static/movies.csv', encoding = "utf8") as csvarchivo:
	    moviesDictReader = csv.DictReader(csvarchivo, delimiter = ',')
	    for row in moviesDictReader:
	        moviesDict.append(row)

	info = ['movieId','title','genres']

	for movie in moviesDict:
		movie['genres'] = movie['genres'].replace("|",",")
	"""
	for movie in moviesDict:
		for i in info:
			print(i, movie[i],sep=': ')
		print("--------------")
	"""

	return moviesDict, info

####################################################################

# Meter las valoraciones en un diccionario

def ratingsDict():
	ratingsDict = []
	with open('static/ratings.csv', encoding = "utf8") as csvarchivo:
	    ratingsDictReader = csv.DictReader(csvarchivo, delimiter = ',')
	    for row in ratingsDictReader:
	        ratingsDict.append(row)

	info = ['userId','movieId','rating']

	"""
	for rating in ratingsDict:
		for i in info:
			print(i, rating[i],sep=': ')
		print("--------------")
	"""

	return ratingsDict, info

####################################################################

# Meter la relación de las películas

def imagesDict():
	linksDict = []
	imagesDict = []
	n = 0
	with open('static/links.csv', encoding = "utf8") as csvarchivo:
		linksDictReader = csv.DictReader(csvarchivo, delimiter = ',')
		for row in linksDictReader:
			#linksDict.append(row)
			if n >= 6405:
				row['imdbId'] = row['imdbId'].zfill(7)
				imdbString = str(requests.get("https://www.imdb.com/title/tt" + str(row['imdbId'])).content)
				inicioTab=imdbString.find("<div class=\"poster\">")
				finTab = imdbString.find("<div class=\"slate\">")
				imdbString=imdbString[inicioTab:finTab]
				inicioTab=imdbString.find("http")
				finTab=imdbString.find("\" />")
				s = ""+imdbString[inicioTab:finTab]
				f = [row["movieId"], s]
				with open('imagenes.csv','a') as fd:
					writer = csv.writer(fd)
					writer.writerow(f)
				#imagesDict.append(imdbString[inicioTab:finTab])
				print(imdbString[inicioTab:finTab])
				print("Num: " + str(n))
			n = n + 1
	info = ['movieId','imdbId']
	print("Terminado")
	return imagesDict, info

if __name__ == "__main__":
	#moviesDict, infomovies = moviesDict()
	#ratingsDict, inforatings = ratingsDict()
	linksDict, infolinks = imagesDict()

	"""	for movie in moviesDict:
		for i in infomovies:
			print(i, movie[i],sep=': ')
		print("--------------")

	for rating in ratingsDict:
		for i in inforatings:
			print(i, rating[i],sep=': ')
		print("--------------")
	
	for link in linksDict:
		for i in infolinks:
			print(i, link[i],sep=': ')
		print("--------------")

	print(" TODAS LAS IMAGENES OBTENIDAS ")
	with open('imagenes.csv', 'w') as csvfile:
		fieldnames = ['first_name', 'last_name', 'Grade']
		writer = csv.DictWriter(csvfile, fieldnames=infolinks)
		writer.writeheader()
		writer.writerows(linksDict)
	"""
