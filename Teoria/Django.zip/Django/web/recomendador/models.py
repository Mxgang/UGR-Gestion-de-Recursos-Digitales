from django.db import models

# Create your models here.

class Movie(models.Model):
	idmovie   = models.AutoField(primary_key=True)	
	title  = models.CharField(max_length=50, blank=True)	
	genre = models.CharField(max_length=50)
	img = models.CharField(max_length=200, blank=True)

class User(models.Model):
	iduser   = models.CharField(max_length=50, primary_key=True)
	nombre = models.CharField(max_length=50, blank=True)

class Rating(models.Model):
	movie_id = models.ForeignKey(Movie, on_delete=models.CASCADE)
	user_id = models.ForeignKey(User, on_delete=models.CASCADE)
	rating = models.CharField(max_length=20)
	comment = models.CharField(max_length=50)

