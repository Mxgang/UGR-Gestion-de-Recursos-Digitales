# recomendador/urls.py
from django.urls import path
from django.conf.urls import url

from . import views

urlpatterns = [

  path('', views.Home.as_view(), name='home'),
  url('grd/home', views.home, name='index2.html'),
  url('creabd', views.insertardatos, name=''),
  #url('recomendador/ej', views.creaalbum, name='index2.html'),
  url('world', views.world, name=''),
  #url('eliminabd', views.eliminabd, name=''),
  url('bd', views.muestrabd, name='basededatos.html'),
  url('nuevousuario', views.nuevouser, name='valorarpelis.html'),
  url('recomendaciones', views.recomendaciones, name='pelis.html')
  
]
