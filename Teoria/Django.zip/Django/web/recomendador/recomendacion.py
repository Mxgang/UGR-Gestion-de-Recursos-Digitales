import csv
import requests

# Meter las películas en un diccionario

def moviesDict():
	moviesDict = []
	with open('static/movies.csv', encoding = "utf8") as csvarchivo:
	    moviesDictReader = csv.DictReader(csvarchivo, delimiter = ',')
	    for row in moviesDictReader:
	        moviesDict.append(row)

	info = ['movieId','title','genres']

	for movie in moviesDict:
		movie['genres'] = movie['genres'].replace("|",",")
	"""
	for movie in moviesDict:
		for i in info:
			print(i, movie[i],sep=': ')
		print("--------------")
	"""

	return moviesDict, info

####################################################################

# Meter las valoraciones en un diccionario


def ratingsDict():
	ratingsDict = []
	with open('static/ratings.csv', encoding = "utf8") as csvarchivo:
	    ratingsDictReader = csv.DictReader(csvarchivo, delimiter = ',')
	    for row in ratingsDictReader:
	        ratingsDict.append(row)

	info = ['userId','movieId','rating']

	"""
	for rating in ratingsDict:
		for i in info:
			print(i, rating[i],sep=': ')
		print("--------------")
	"""

	return ratingsDict, info

####################################################################

# Meter la relación de las películas

def imagesDict():
	moviesDict = []
	with open('static/imagenes.csv', encoding = "utf8") as csvarchivo:
	    moviesDictReader = csv.DictReader(csvarchivo, delimiter = ',')
	    for row in moviesDictReader:
	        moviesDict.append(row)

	info = ['movieId','img']

	"""
	for movie in moviesDict:
		for i in info:
			print(i, movie[i],sep=': ')
		print("--------------")
	"""

	return moviesDict, info

if __name__ == "__main__":
	moviesDict, infomovies = moviesDict()
	ratingsDict, inforatings = ratingsDict()
	linksDict, infolinks = imagesDict()

	for movie in moviesDict:
		for i in infomovies:
			print(i, movie[i],sep=': ')
		print("--------------")

	for rating in ratingsDict:
		for i in inforatings:
			print(i, rating[i],sep=': ')
		print("--------------")

	for link in linksDict:
		for i in infolinks:
			print(i, link[i],sep=': ')
		print("--------------")

