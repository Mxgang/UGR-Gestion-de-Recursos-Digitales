from django import forms

class User(forms.form):
	m[20]   = forms.CharField(max_length=50)
	r[20]  = forms.IntegerField()

