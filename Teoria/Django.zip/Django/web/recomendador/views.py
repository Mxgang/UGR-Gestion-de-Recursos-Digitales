# recomendador/views.py

from django.shortcuts import render, HttpResponse
from .models import Movie, User, Rating
from django.views.generic import TemplateView

from .recomendacion import moviesDict, ratingsDict, imagesDict

import random
import math

num_pelis = 20

class Home(TemplateView):
    template_name = 'account/login.html'


def world(request):
    return HttpResponse('Hello World!')

def home(request):
	return render(request, 'index2.html')


def insertardatos(request):
	#movies,infomovies = moviesDict()
	#rating,inforatings = ratingsDict()
	imagenes, infoimg = imagesDict()

	"""for mov in movies:
		m = Movie(idmovie=mov[infomovies[0]] , title=mov[infomovies[1]], genre=mov[infomovies[2]] , img="imagen")
		m.save()	
	for rat in rating:
		m = Movie.objects.get(idmovie=rat[inforatings[1]])
		
		if User.objects.filter(iduser=rat[inforatings[0]]).exists():
			u = User.objects.get(iduser=rat[inforatings[0]])
			r = Rating(movie_id=m ,user_id=u , rating=rat[inforatings[2]] , comment="comentario" )	
			r.save()
		else:
			u = User(iduser=rat[inforatings[0]])
			u.save()
			r = Rating(movie_id=m ,user_id=u , rating=rat[inforatings[2]] , comment="comentario" )	
			r.save()		
		
			
	"""
	
	for p in imagenes:
		peli = Movie.objects.get(idmovie=p[infoimg[0]])
		peli.img = p[infoimg[1]]
		peli.save()

	return HttpResponse('Base de datos completa')

def nuevouser(request):
	peliculas = []
	for i in range (num_pelis):
		r = random.randint(1, 9735)
		m = random.choice(Movie.objects.all())	
		#m = Movie.objects.get()
		
		mov = { "title": m.title, "genre": m.genre, "id": m.idmovie, "num": i+1 }
		peliculas.append(mov)
	movies = { "movies": peliculas }
	return render(request, 'valorarpelis.html', movies)

def muestrabd(request):
	u = User.objects.filter()[0:5]
	us = []
	m = []
	rat = []
	for user in u:
		usuario = { "iduser": user.iduser }
		us.append(usuario)
		r = Rating.objects.filter(user_id=user.iduser)
		for rating in r:
			movie = Movie.objects.get(idmovie=rating.movie_id.idmovie)
			mov = { "title": movie.title, "genres": movie.genre, "img": movie.img }
			m.append(mov)
			ra = { "movie": rating.movie_id.title, "user":rating.user_id.iduser, "rating": rating.rating}
			rat.append(ra)
	d ={ 'usuarios': us, 'peliculas': m, "ratings": rat }
	return render(request, 'basededatos.html', d)

def recomendaciones(request):
	if request.method == 'POST':
		# Primero obtenemos las 20 peliculas y sus valoraciones		
		m = ""
		media_usuario = 0.0
		peliculas = {}
		for i in range(num_pelis):
			o = str(i+1)
			peliculas[request.POST[o+"name"]] = request.POST[o]
			media_usuario = media_usuario + int(request.POST[o])
			#m = m + "Pelicula: "+request.POST[o+"name"]+" rating: "+request.POST[o]
		media_usuario = media_usuario / num_pelis
		# Una vez tenemos las peliculas del nuevo usuario obtenemos sus vecinos
		alluser = User.objects.all()[1:100]
		correlacion = {}
		for user in alluser:
			#m = m + "Vecino: "+str(user.iduser)
			valoraciones = Rating.objects.filter(user_id=user)
			media_vecino = 0.0
			val = {}
			for valoracion in valoraciones:				
				#m = m + "val: "+str(valoracion.movie_id.idmovie)
				media_vecino = media_vecino + float(valoracion.rating)
				if str(valoracion.movie_id.idmovie) in peliculas.keys():
					val[str(valoracion.movie_id.idmovie)] = valoracion.rating
					#m = m + "val: "+str(valoracion.movie_id.idmovie)
			if len(val) > 0:
				m =m+"len "+str(len(val))
				media_vecino = media_vecino / len(valoraciones)
				numerador = 0.0
				denominador = 0.0
				denominador_1 = denominador_2 = 0.0
				keys = val.keys()
				#m = m + "vecino: "
				for i in keys:
					miembro1 = float(peliculas[i])-media_usuario
					#m = m + "miembro1: "+str(float(peliculas[i]))+"--"+str(media_usuario)
					miembro2 = float(val[i])-media_vecino
					#m = m + "miembro2: "+str(val[i])+"--"+str(media_vecino)
					#m = m + "numerador: "+str(miembro1*miembro2)
					numerador += float(miembro1 * miembro2)
					#m = m + "DESPUES: "+str(numerador)
					denominador_1 += miembro1*miembro1
					denominador_2 += miembro2*miembro2
				#m = m + "numerador: "+str(numerador)  +"denominador"+str(denominador_1)+"--"+str(denominador_2)
				
				denominador_1 = math.sqrt(denominador_1)
				denominador_2 = math.sqrt(denominador_2)
				#m = m + "antes: "+str(denominador)
				#m = m + "den 1: "+str(denominador_1)
				#m = m + "den 2: "+str(denominador_2)
				denominador = denominador_1 * denominador_2
				#m = m + "despues: "+str(denominador_1+denominador_2)
				#m = m + "num: "+str(numerador)	
				correlacion[user.iduser]=float(numerador/denominador)

		k = {}
		vec = []
		val = []
		for w in sorted(correlacion, key=correlacion.get, reverse=True):
			k[w] = correlacion[w]
			vec.append(w)
		k_users = []
		mejores_pelis = []
		
		for i in range(10):
			valoracion = []
			val.append(k[vec[i]])
			k_users.append(vec[i])
			rat = Rating.objects.order_by('rating').filter(user_id=k_users[i]).reverse()[0:2]
			for r in rat:
				valoracion.append(r.rating)
				mejores_pelis.append(r.movie_id.idmovie)

		
		mejor_predicciones = {}
		for i in mejores_pelis:
			peli = Movie.objects.get(idmovie=i)
			valor = 0.0
			media = 0.0
			for w in range(len(k_users)):
				user = User.objects.get(iduser=k_users[w])
				if Rating.objects.filter(movie_id=peli.idmovie, user_id=user).exists():
					r = Rating.objects.get(movie_id=peli.idmovie, user_id=user)
					valor += float(r.rating)*float(val[w])
					media += val[w]
			mejor_predicciones[peli.idmovie] = valor/media
		peliculas_recomendadas = {}
		for w in sorted(mejor_predicciones, key=mejor_predicciones.get, reverse=True):
			peliculas_recomendadas[w] = mejor_predicciones[w]
		
		final = list(peliculas_recomendadas.keys())

		pf = {}
		pelis = []
		for i in range(10):
			pf[final[i]] = peliculas_recomendadas[final[i]]
			p = Movie.objects.get(idmovie=final[i])
			mov = {"title": p.title, "genre": p.genre, "img": p.img}
			pelis.append(mov)
		d = {"peliculas": pelis}
		return render(request, 'basededatos.html', d)#HttpResponse(str(pf))


