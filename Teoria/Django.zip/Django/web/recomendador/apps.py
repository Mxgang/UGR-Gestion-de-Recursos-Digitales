from django.apps import AppConfig


class RecomendadorConfig(AppConfig):
    name = 'recomendador'
